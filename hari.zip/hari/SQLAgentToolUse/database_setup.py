"""
================================================================================
EXPERIMENT 2: SQL AGENT TOOL USE
Database Setup & Seed Script (company.db)
================================================================================
Creates a realistic SQLite relational database with four interrelated tables:
- departments
- employees
- projects
- sales
================================================================================
"""

import sqlite3
import os
import sys

# Ensure UTF-8 output
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "company.db")

def init_database(db_path: str = DB_PATH):
    """Initializes and seeds the enterprise database."""
    if os.path.exists(db_path):
        os.remove(db_path)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Enable foreign keys
    cursor.execute("PRAGMA foreign_keys = ON;")

    # 1. Departments Table
    cursor.execute("""
    CREATE TABLE departments (
        dept_id INTEGER PRIMARY KEY AUTOINCREMENT,
        dept_name TEXT NOT NULL UNIQUE,
        budget REAL NOT NULL,
        location TEXT NOT NULL
    );
    """)

    # 2. Employees Table
    cursor.execute("""
    CREATE TABLE employees (
        emp_id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        dept_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        salary REAL NOT NULL,
        hire_date TEXT NOT NULL,
        FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
    );
    """)

    # 3. Projects Table
    cursor.execute("""
    CREATE TABLE projects (
        project_id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_name TEXT NOT NULL,
        dept_id INTEGER NOT NULL,
        budget REAL NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Planning', 'Active', 'Completed', 'On Hold')),
        FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
    );
    """)

    # 4. Sales Table
    cursor.execute("""
    CREATE TABLE sales (
        sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
        emp_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        sale_date TEXT NOT NULL,
        region TEXT NOT NULL,
        FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
    );
    """)

    # Seed Departments
    departments_data = [
        (1, 'Engineering', 750000.0, 'San Francisco'),
        (2, 'Sales', 450000.0, 'New York'),
        (3, 'Human Resources', 180000.0, 'Chicago'),
        (4, 'Marketing', 320000.0, 'Austin'),
        (5, 'Finance', 400000.0, 'Boston')
    ]
    cursor.executemany("INSERT INTO departments VALUES (?, ?, ?, ?);", departments_data)

    # Seed Employees
    employees_data = [
        (101, 'Alex', 'Chen', 1, 'Principal Software Engineer', 165000.0, '2021-03-15'),
        (102, 'Sarah', 'Miller', 1, 'Senior Backend Engineer', 140000.0, '2022-01-10'),
        (103, 'David', 'Kim', 1, 'Frontend Engineer', 115000.0, '2023-06-01'),
        (104, 'Jessica', 'Taylor', 2, 'Senior Account Executive', 125000.0, '2020-09-01'),
        (105, 'Michael', 'Brown', 2, 'Sales Representative', 85000.0, '2022-11-15'),
        (106, 'Emily', 'Davis', 2, 'Regional Sales Lead', 135000.0, '2019-04-20'),
        (107, 'James', 'Wilson', 3, 'HR Director', 120000.0, '2018-08-12'),
        (108, 'Rachel', 'Green', 3, 'Talent Acquisition Specialist', 78000.0, '2023-02-01'),
        (109, 'Robert', 'Garcia', 4, 'Marketing Manager', 110000.0, '2021-07-19'),
        (110, 'Amanda', 'White', 4, 'Growth Strategist', 95000.0, '2022-08-05'),
        (111, 'Thomas', 'Hall', 5, 'Financial Controller', 145000.0, '2019-12-01'),
        (112, 'Lisa', 'Johnson', 5, 'Senior Financial Analyst', 105000.0, '2022-04-18')
    ]
    cursor.executemany("INSERT INTO employees VALUES (?, ?, ?, ?, ?, ?, ?);", employees_data)

    # Seed Projects
    projects_data = [
        (1, 'AI Inference Gateway', 1, 280000.0, 'Active'),
        (2, 'Cloud Microservices Migration', 1, 350000.0, 'Active'),
        (3, 'Q3 Global Brand Campaign', 4, 150000.0, 'Completed'),
        (4, 'Enterprise ERP Upgrade', 5, 220000.0, 'Planning'),
        (5, 'HR Portal Automation', 3, 60000.0, 'Completed'),
        (6, 'CRM Sales Pipeline V2', 2, 110000.0, 'Active')
    ]
    cursor.executemany("INSERT INTO projects VALUES (?, ?, ?, ?, ?);", projects_data)

    # Seed Sales Transactions
    sales_data = [
        (1, 104, 45000.0, '2023-01-15', 'North America'),
        (2, 106, 72000.0, '2023-02-10', 'EMEA'),
        (3, 105, 28000.0, '2023-02-28', 'North America'),
        (4, 104, 63000.0, '2023-03-12', 'APAC'),
        (5, 106, 89000.0, '2023-04-05', 'North America'),
        (6, 105, 34000.0, '2023-04-22', 'LATAM'),
        (7, 104, 51000.0, '2023-05-18', 'North America'),
        (8, 106, 94000.0, '2023-06-01', 'EMEA'),
        (9, 105, 41000.0, '2023-06-19', 'North America'),
        (10, 106, 60000.0, '2023-07-04', 'APAC')
    ]
    cursor.executemany("INSERT INTO sales VALUES (?, ?, ?, ?, ?);", sales_data)

    conn.commit()
    conn.close()
    print(f"[+] Database successfully initialized and seeded at: {db_path}")

if __name__ == "__main__":
    init_database()
