"""
================================================================================
EXPERIMENT 2: SQL AGENT TOOL USE
CLI Demonstration Runner & Interactive REPL (run_agent.py)
================================================================================
Demonstrates the ReAct Agent across 3 core scenarios:
1. Scenario 1: Relational Aggregation (SUM, AVG, GROUP BY)
2. Scenario 2: Multi-Table JOIN (employees + departments + sales)
3. Scenario 3: Error Recovery & Self-Correction (handling missing column and schema recovery)
================================================================================
"""

import sys
import os
import json
import argparse
from react_sql_agent import SQLReActAgent

# Ensure UTF-8 output
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def run_demonstration_suite():
    print("=" * 80)
    print("   EXPERIMENT 2: SQL AGENT TOOL USE (ReAct FRAMEWORK DEMONSTRATION)   ")
    print("=" * 80)
    print("Agent Architecture: Reasoning + Acting (Yao et al., 2022)")
    print("Available Tools: [list_tables, describe_table, execute_sql]")
    print("Target Database: SQLite (company.db)")
    print("=" * 80)

    agent = SQLReActAgent()
    demo_scenarios = [
        {
            "id": 1,
            "title": "Scenario 1: Relational Aggregation",
            "question": "What is the total salary and headcount in the Engineering department?",
            "simulate_error": False
        },
        {
            "id": 2,
            "title": "Scenario 2: Multi-Table JOIN Across 3 Relational Tables",
            "question": "List the top 3 sales representatives who generated the highest total sales volume along with their department name.",
            "simulate_error": False
        },
        {
            "id": 3,
            "title": "Scenario 3: Autonomous Error Recovery & Schema-Guided Self-Correction",
            "question": "Find the annual budget and location of the Human Resources department.",
            "simulate_error": True
        }
    ]

    all_logs = []

    for item in demo_scenarios:
        print("\n" + "#" * 80)
        print(f"  DEMO {item['id']}: {item['title'].upper()}")
        print("#" * 80)
        
        result = agent.run(
            user_question=item["question"],
            verbose=True,
            simulate_error_recovery=item["simulate_error"]
        )

        log_entry = {
            "demo_id": item["id"],
            "title": item["title"],
            "question": result["question"],
            "total_steps": result["total_steps"],
            "elapsed_seconds": round(result["elapsed_seconds"], 4),
            "final_answer": result["final_answer"],
            "steps": [
                {
                    "step": s.step_number,
                    "thought": s.thought,
                    "action": s.action,
                    "action_input": s.action_input,
                    "observation": s.observation
                }
                for s in result["steps"]
            ]
        }
        all_logs.append(log_entry)

    # Export execution logs
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, "react_execution_log.json")
    with open(log_file, "w", encoding="utf-8") as f:
        json.dump(all_logs, f, indent=2)

    # Export markdown report
    md_file = os.path.join(base_dir, "sql_agent_report.md")
    with open(md_file, "w", encoding="utf-8") as f:
        f.write("# Experiment 2: SQL Agent Tool Use - Execution Report\n\n")
        f.write("## Overview\n\n")
        f.write("This report documents the autonomous execution of the ReAct (Reasoning + Acting) SQL Agent on `company.db`.\n\n")
        
        for item in all_logs:
            f.write(f"### {item['title']}\n\n")
            f.write(f"- **User Question**: `{item['question']}`\n")
            f.write(f"- **ReAct Steps Executed**: {item['total_steps']}\n")
            f.write(f"- **Total Time**: {item['elapsed_seconds']}s\n\n")
            f.write("#### Step-by-Step Reasoning Trace:\n\n")
            for s in item["steps"]:
                f.write(f"**Step {s['step']}**:\n")
                f.write(f"- *Thought*: {s['thought']}\n")
                f.write(f"- *Action*: `{s['action']}`\n")
                f.write(f"- *Action Input*:\n```sql\n{s['action_input']}\n```\n")
                f.write(f"- *Observation*:\n```text\n{s['observation']}\n```\n\n")
            f.write(f"**Final Answer**:\n> {item['final_answer']}\n\n---\n\n")

    print("\n" + "=" * 80)
    print(" [✓] EXPERIMENT 2 BENCHMARK SUITE COMPLETED SUCCESSFULLY!")
    print(f"     Execution Log: {log_file}")
    print(f"     Report Markdown: {md_file}")
    print("=" * 80 + "\n")

def interactive_mode():
    agent = SQLReActAgent()
    print("=" * 80)
    print("  SQL ReAct Agent - Interactive REPL Mode")
    print("  Type your question in natural language (or 'exit' / 'quit' to stop).")
    print("=" * 80 + "\n")

    while True:
        try:
            user_input = input("\nEnter your question > ").strip()
            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "q"):
                print("Exiting interactive session.")
                break
            agent.run(user_question=user_input, verbose=True)
        except (KeyboardInterrupt, EOFError):
            print("\nExiting interactive session.")
            break

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SQL ReAct Agent Runner")
    parser.add_argument("--interactive", "-i", action="store_true", help="Launch interactive REPL mode")
    args = parser.parse_args()

    if args.interactive:
        interactive_mode()
    else:
        run_demonstration_suite()
