# EXPERIMENT 2: SQL AGENT TOOL USE

## Develop a ReAct-Based Agent Using Database Tools

---

### 1. AIM
To design, implement, and evaluate an autonomous **ReAct (Reasoning + Acting)** database agent capable of answering complex natural language queries over a relational SQLite database by dynamically interacting with database tools, inspecting schemas, generating safe SQL queries, and self-correcting syntax or schema errors through iterative feedback loops.

---

### 2. OBJECTIVES
- Implement the foundational **ReAct framework** ($Thought \rightarrow Action \rightarrow Action\ Input \rightarrow Observation$) for goal-driven database querying.
- Engineer specialized database interaction tools with strict security and read-only guardrails (`list_tables`, `describe_table`, `validate_sql`, `execute_sql`).
- Implement autonomous **error recovery and self-correction**: when a query fails (e.g., nonexistent column or syntax error), the agent analyzes the error observation, inspects the schema, corrects the query, and re-executes.
- Demonstrate multi-turn reasoning on complex relational operations including aggregations, multi-table JOINs, and subqueries.

---

### 3. THEORETICAL BACKGROUND

#### 3.1 The ReAct Paradigm (Yao et al., 2022)
Traditional Language Models suffer from two fundamental bottlenecks:
1. **Hallucination in Static Reasoning**: Models generate plausible-sounding but factually false answers when asked to query external private data.
2. **Blind Action Execution**: Models acting without internal reasoning often execute invalid or repetitive actions without diagnosing failures.

**ReAct (Reasoning + Acting)** synergizes language reasoning traces with concrete tool executions:
- **Reasoning Traces (Thoughts)**: Enable the model to track progress, decompose complex user intents into manageable sub-goals, synthesize observations, and diagnose errors.
- **Actions (Tool Invocations)**: Enable the model to interface with external environments (such as an SQLite database engine) to retrieve ground-truth data.
- **Observations (Environment Feedback)**: Inject real-time state changes or error messages back into the agent's prompt context, closing the feedback loop.

```mermaid
graph TD
    A[User Question] --> B[Thought: Reason & Formulate Plan]
    B --> C[Action: Choose Database Tool]
    C --> D[Action Input: Provide Arguments]
    D --> E[Environment: Execute Database Tool]
    E --> F[Observation: Query Results or Error Feedback]
    F --> G{Is Information Complete?}
    G -- No: Needs more data or needs error fix --> B
    G -- Yes: Information sufficient --> H[Thought: Synthesize Final Conclusion]
    H --> I[Final Answer to User]
```

---

### 4. DATABASE TOOLS SPECIFICATION

The agent has access to four modular tools:

| Tool Name | Input Signature | Output Description | Security Guardrail |
| :--- | :--- | :--- | :--- |
| `list_tables()` | None | Returns a comma-separated list of all tables in the database. | Read-only system catalog query. |
| `describe_table(table_name)` | `table_name: str` | Returns column definitions, data types, primary keys, foreign keys, and 3 sample rows. | Verifies table existence before executing PRAGMA. |
| `validate_sql(sql_query)` | `sql_query: str` | Checks whether the query is a valid read-only `SELECT` statement. | Blocks destructive keywords (`DROP`, `DELETE`, `UPDATE`, `INSERT`, `ALTER`, `TRUNCATE`). |
| `execute_sql(sql_query)` | `sql_query: str` | Executes query and formats rows into markdown table; returns database error on failure. | Runs `validate_sql` guardrail before execution. |

---

### 5. DATABASE ENTITY-RELATIONSHIP (ER) SCHEMA

The target database (`company.db`) contains four interrelated relational tables:

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : "employs"
    DEPARTMENTS ||--o{ PROJECTS : "funds"
    EMPLOYEES ||--o{ SALES : "generates"

    DEPARTMENTS {
        int dept_id PK
        string dept_name UK
        float budget
        string location
    }

    EMPLOYEES {
        int emp_id PK
        string first_name
        string last_name
        int dept_id FK
        string role
        float salary
        string hire_date
    }

    PROJECTS {
        int project_id PK
        string project_name
        int dept_id FK
        float budget
        string status
    }

    SALES {
        int sale_id PK
        int emp_id FK
        float amount
        string sale_date
        string region
    }
```

---

### 6. EVALUATION SCENARIOS & EXECUTION TRACES

#### 6.1 Scenario 1: Relational Aggregation
**Question**: *"What is the total salary and headcount in the Engineering department?"*

- **Step 1**:
  - *Thought*: Discover which tables contain department and employee records.
  - *Action*: `list_tables`
  - *Observation*: `Available Tables: departments, employees, projects, sales`
- **Step 2**:
  - *Thought*: Inspect `employees` schema to confirm salary column and foreign key to department.
  - *Action*: `describe_table` | *Input*: `employees`
  - *Observation*: Columns: `emp_id`, `first_name`, `last_name`, `dept_id`, `salary`, `hire_date`. Foreign key: `dept_id -> departments(dept_id)`.
- **Step 3**:
  - *Thought*: Formulate SQL query joining `employees` with `departments` and aggregate metrics.
  - *Action*: `execute_sql`
  - *Input*:
    ```sql
    SELECT d.dept_name, COUNT(e.emp_id) AS employee_count,
           PRINTF('$%,.2f', SUM(e.salary)) AS total_payroll,
           PRINTF('$%,.2f', AVG(e.salary)) AS average_salary
    FROM employees e JOIN departments d ON e.dept_id = d.dept_id
    WHERE d.dept_name = 'Engineering' GROUP BY d.dept_name;
    ```
  - *Observation*:
    ```text
    | dept_name | employee_count | total_payroll | average_salary |
    | Engineering | 3 | $420,000.00 | $140,000.00 |
    ```
- **Final Answer**: *"The Engineering department employs 3 engineers with a total annual payroll of $420,000.00 (Average salary: $140,000.00)."*

---

#### 6.2 Scenario 2: Multi-Table JOIN Across 3 Relational Tables
**Question**: *"List the top 3 sales representatives who generated the highest total sales volume along with their department name."*

- **Step 1**: `list_tables` $\rightarrow$ Discovers `departments`, `employees`, `projects`, `sales`.
- **Step 2**: `describe_table(employees)` $\rightarrow$ Verifies employee names and `dept_id`.
- **Step 3**: `describe_table(sales)` $\rightarrow$ Verifies `amount` column and `emp_id` foreign key.
- **Step 4**: `execute_sql`:
  ```sql
  SELECT e.first_name || ' ' || e.last_name AS employee_name,
         d.dept_name AS department,
         COUNT(s.sale_id) AS total_deals,
         PRINTF('$%,.2f', SUM(s.amount)) AS total_sales_volume
  FROM employees e
  JOIN departments d ON e.dept_id = d.dept_id
  JOIN sales s ON e.emp_id = s.emp_id
  GROUP BY e.emp_id
  ORDER BY SUM(s.amount) DESC LIMIT 3;
  ```
- **Observation**:
  ```text
  | Emily Davis | Sales | 4 | $315,000.00 |
  | Jessica Taylor | Sales | 3 | $159,000.00 |
  | Michael Brown | Sales | 3 | $103,000.00 |
  ```
- **Final Answer**: Formulates ranked list of top performers with deal counts and dollar volume.

---

#### 6.3 Scenario 3: Autonomous Error Recovery & Schema-Guided Self-Correction
**Question**: *"Find the annual budget and location of the Human Resources department."*

- **Step 1**: `list_tables` $\rightarrow$ Returns tables.
- **Step 2 (Initial Guess)**:
  - *Thought*: Let me query the budget for Human Resources directly.
  - *Action*: `execute_sql` | *Input*: `SELECT department_budget FROM departments WHERE dept_name = 'Human Resources';`
  - *Observation*: `Error: SQL Syntax Error: no such column: department_budget`
- **Step 3 (Self-Correction & Schema Grounding)**:
  - *Thought*: The previous query failed with `'no such column: department_budget'`. I made an assumption about the column name. I must inspect the exact schema of `departments` using `describe_table` to find the correct column.
  - *Action*: `describe_table` | *Input*: `departments`
  - *Observation*: Table `departments` has columns: `dept_id`, `dept_name`, `budget`, `location`.
- **Step 4 (Corrected Query Execution)**:
  - *Thought*: The column is named `budget`, not `department_budget`. Executing corrected query.
  - *Action*: `execute_sql` | *Input*: `SELECT dept_id, dept_name, budget, location FROM departments WHERE dept_name = 'Human Resources';`
  - *Observation*: `| 3 | Human Resources | 180000.0 | Chicago |`
- **Final Answer**: *"The Human Resources department (Dept ID: 3, located in Chicago) has an annual budget of $180,000.00."*

---

### 7. VIVA VOCE QUESTIONS & ANSWERS

**Q1: What does ReAct stand for, and who proposed it?**
> *Answer*: ReAct stands for **Reasoning + Acting**. It was proposed by Yao et al. (Princeton University & Google Research) in their 2022 paper *"ReAct: Synergizing Reasoning and Acting in Language Models"*.

**Q2: How does ReAct differ from standard Chain-of-Thought (CoT)?**
> *Answer*: CoT is purely static internal reasoning without environmental interaction; the model cannot query external APIs, databases, or search engines. ReAct interleaves internal reasoning ("Thought") with external environment execution ("Action") and incorporates feedback ("Observation"), eliminating hallucinations about dynamic or private data.

**Q3: Explain the significance of the "Observation" step in the ReAct loop.**
> *Answer*: The Observation step feeds the actual output or error code from the external tool back into the LLM context. This provides factual grounding and enables self-correction: if a query fails, the model observes the exact database error and plans a recovery action.

**Q4: Why should a SQL agent first inspect the database schema rather than guessing SQL queries immediately?**
> *Answer*: Relational databases enforce strict schemas. Guessing column names, table names, or foreign key relationships frequently leads to `OperationalError` (e.g. `no such column`). Calling `describe_table` first ensures syntactically correct queries with proper column aliases and JOIN keys.

**Q5: What security guardrails are essential when building a SQL agent?**
> *Answer*:
> 1. Restrict execution to read-only statements (`SELECT`).
> 2. Block DDL and destructive DML keywords (`DROP`, `DELETE`, `UPDATE`, `INSERT`, `ALTER`, `TRUNCATE`).
> 3. Enforce maximum row limits (`LIMIT N`) to prevent memory exhaustion.
> 4. Use connection-level read-only access flags and prepared statement parameterization to guard against SQL injection.

**Q6: What prevents a ReAct agent from entering an infinite loop?**
> *Answer*: An iteration guardrail (`max_iterations`, typically 5 to 10 steps). If the agent fails to reach a `Final Answer` within the allowed step budget, the execution loop terminates gracefully with an error report.

**Q7: How does the ReAct agent perform self-correction when a query fails?**
> *Answer*: When `execute_sql` returns an error string (e.g. `no such column: department_budget`), the agent's next `Thought` step inspects the error message, diagnoses the root cause (e.g. incorrect column name), triggers `describe_table` to retrieve valid column names, reconstructs the SQL statement, and re-executes.

**Q8: What is the difference between ReAct and the MRKL (Modular Reasoning, Knowledge and Language) system?**
> *Answer*: MRKL uses a hardcoded router to dispatch tasks to specialized modules. ReAct treats tool use as an emergent, multi-step conversation in which the language model dynamically reasons about which tool to call, inspects the result, and decides the next action iteratively.

**Q9: What is the benefit of formatting SQL execution results as Markdown tables?**
> *Answer*: Markdown tables provide clear structural delimiters (headers, separators, rows) that language models can parse token-by-token with minimal ambiguity, facilitating accurate synthesis in the `Final Answer`.

**Q10: Can ReAct be combined with other agent patterns like Plan-and-Solve or Reflection?**
> *Answer*: Yes. In advanced agent architectures, a high-level planner (Plan-and-Solve) breaks a multi-table business request into sub-queries, each sub-query is executed via a ReAct loop with tools, and a Reflection step evaluates the output quality before presenting the final response.
