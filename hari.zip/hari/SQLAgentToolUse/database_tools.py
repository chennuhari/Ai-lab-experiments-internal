"""
================================================================================
EXPERIMENT 2: SQL AGENT TOOL USE
Database Tools Module (database_tools.py)
================================================================================
Provides four standard database inspection and execution tools for the ReAct agent:
1. list_tables()
2. describe_table(table_name)
3. validate_sql(sql_query)
4. execute_sql(sql_query)
================================================================================
"""

import sqlite3
import os
import re
from typing import Dict, Any, List, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "company.db")

class DatabaseTools:
    """Encapsulates SQL database tools with safety guardrails and error reporting."""

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        if not os.path.exists(self.db_path):
            from database_setup import init_database
            init_database(self.db_path)

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    # Tool 1: list_tables
    def list_tables(self) -> str:
        """Lists all user tables currently existing in the database."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
                tables = [row["name"] for row in cursor.fetchall()]
                return f"Available Tables: {', '.join(tables)}"
        except Exception as e:
            return f"Error listing tables: {str(e)}"

    # Tool 2: describe_table
    def describe_table(self, table_name: str) -> str:
        """
        Retrieves the exact schema definition, column data types, foreign keys,
        and 3 sample rows for the specified table.
        """
        table_name = table_name.strip("`'\" ;\n")
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                # Verify table exists
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?;", (table_name,))
                if not cursor.fetchone():
                    return f"Error: Table '{table_name}' does not exist in database. Use list_tables to see valid names."

                # Get column information
                cursor.execute(f"PRAGMA table_info({table_name});")
                cols = cursor.fetchall()
                col_defs = []
                col_names = []
                for c in cols:
                    pk = " [PRIMARY KEY]" if c["pk"] else ""
                    notnull = " NOT NULL" if c["notnull"] else ""
                    col_defs.append(f"  - {c['name']} ({c['type']}{notnull}{pk})")
                    col_names.append(c["name"])

                # Get foreign key information
                cursor.execute(f"PRAGMA foreign_key_list({table_name});")
                fks = cursor.fetchall()
                fk_defs = []
                for fk in fks:
                    fk_defs.append(f"  - {fk['from']} -> references {fk['table']}({fk['to']})")

                # Sample data (up to 3 rows)
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 3;")
                sample_rows = cursor.fetchall()
                sample_str_list = []
                for r in sample_rows:
                    sample_dict = {col: r[col] for col in col_names}
                    sample_str_list.append(str(sample_dict))

                output = [
                    f"Table: {table_name}",
                    "Columns:",
                    "\n".join(col_defs)
                ]
                if fk_defs:
                    output.extend(["Foreign Keys:", "\n".join(fk_defs)])
                if sample_str_list:
                    output.extend(["Sample Rows (first 3):", "\n".join(sample_str_list)])

                return "\n".join(output)

        except Exception as e:
            return f"Error describing table '{table_name}': {str(e)}"

    # Tool 3: validate_sql
    def validate_sql(self, sql_query: str) -> Dict[str, Any]:
        """
        Validates safety guardrails and syntax.
        Ensures queries are read-only (SELECT only) and disallows destructive keywords.
        """
        cleaned = sql_query.strip().rstrip(";")
        if not cleaned:
            return {"is_valid": False, "error": "Query string is empty."}

        # Check for non-SELECT operations
        forbidden_patterns = [
            r"\bDROP\b", r"\bDELETE\b", r"\bUPDATE\b", r"\bINSERT\b",
            r"\bALTER\b", r"\bTRUNCATE\b", r"\bREPLACE\b", r"\bATTACH\b", r"\bDETACH\b"
        ]
        for pattern in forbidden_patterns:
            if re.search(pattern, cleaned, re.IGNORECASE):
                return {
                    "is_valid": False,
                    "error": f"Security violation: Query contains disallowed modification command matching '{pattern}'."
                }

        if not re.match(r"^\s*SELECT\b", cleaned, re.IGNORECASE):
            return {
                "is_valid": False,
                "error": "Security policy violation: Only read-only SELECT queries are permitted."
            }

        # Syntax check via SQLite EXPLAIN
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(f"EXPLAIN {cleaned};")
            return {"is_valid": True, "message": "SQL syntax and security guardrails validated successfully."}
        except sqlite3.OperationalError as e:
            return {"is_valid": False, "error": f"SQL Syntax Error: {str(e)}"}
        except Exception as e:
            return {"is_valid": False, "error": f"Validation Error: {str(e)}"}

    # Tool 4: execute_sql
    def execute_sql(self, sql_query: str) -> str:
        """
        Executes a validated SELECT SQL query and returns formatted rows.
        If an error occurs, returns detailed error feedback enabling the agent to self-correct.
        """
        validation = self.validate_sql(sql_query)
        if not validation["is_valid"]:
            return f"Error: {validation['error']}"

        cleaned = sql_query.strip().rstrip(";")
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(cleaned)
                rows = cursor.fetchall()
                if not rows:
                    return "Result: 0 rows returned (Empty result set)."

                headers = [desc[0] for desc in cursor.description]
                
                # Format as clean markdown table
                header_row = "| " + " | ".join(headers) + " |"
                separator_row = "| " + " | ".join(["---"] * len(headers)) + " |"
                data_rows = []
                for row in rows:
                    data_rows.append("| " + " | ".join(str(row[h]) for h in headers) + " |")

                markdown_table = "\n".join([header_row, separator_row] + data_rows)
                return f"Result ({len(rows)} row{'s' if len(rows) > 1 else ''}):\n{markdown_table}"

        except sqlite3.OperationalError as e:
            return f"Database Operational Error: {str(e)}"
        except Exception as e:
            return f"Execution Error: {str(e)}"
