# EXPERIMENT 1: REASONING MODEL BENCHMARK

## Compare Outputs Across Different Prompting Strategies

---

### 1. AIM
To design, implement, and evaluate a benchmarking testbed that systematically analyzes the reasoning capabilities of Large Language Models (LLMs) across four distinct prompting paradigms:
1. **Direct (Zero-Shot) Prompting**
2. **Few-Shot Prompting**
3. **Chain-of-Thought (CoT) Prompting**
4. **Self-Consistency / Step-by-Step with Verification Prompting**

The experiment measures and compares **Task Accuracy (%)**, **Inference Latency (seconds)**, **Token Consumption (Prompt, Completion, Total)**, and **Token Efficiency**.

---

### 2. OBJECTIVES
- Understand how prompt formulation directly impacts intermediate deduction in transformer-based architectures.
- Measure the empirical trade-offs between computational overhead (token count, inference latency) and reasoning fidelity.
- Identify specific failure modes (e.g., calculation errors, counter-intuitive scaling traps, syllogistic fallacies) prevalent in naive zero-shot generation.
- Formulate standardized templates for intermediate step decomposition and self-consistency verification.

---

### 3. THEORETICAL BACKGROUND

#### 3.1 The Next-Token Prediction Paradigm
Autoregressive transformers compute probabilities for the next token based strictly on preceding context tokens:
$$P(y_1, y_2, \dots, y_T \mid x) = \prod_{t=1}^{T} P(y_t \mid x, y_1, \dots, y_{t-1})$$

When prompted with a complex multi-step reasoning problem under **Direct Prompting**, the model is forced to predict the final token $y$ in a single forward pass without intermediate computation tokens. For tasks requiring multi-step state tracking, working memory, or dimensional analysis, the model frequently fails because the latent representations cannot bridge complex intermediate mathematical transformations in one step.

#### 3.2 Prompting Strategies Evaluated

| Strategy | Formulation / Mechanism | Primary Strength | Primary Weakness |
| :--- | :--- | :--- | :--- |
| **1. Direct (Zero-Shot)** | Direct question asking for immediate answer without intermediate guidance. | Lowest latency and minimal token cost. | Fails on counter-intuitive, multi-step math and deductive constraints. |
| **2. Few-Shot** | Prepends $k$ solved exemplars showing input-output pairs $(x_i, y_i)$ before test query $x$. | Teaches output format, tone, and surface pattern matching. | Still lacks explicit intermediate reasoning steps on complex reasoning. |
| **3. Chain-of-Thought (CoT)** | Prompts the model to "Think step-by-step" or provides demonstrations with explicit reasoning paths. | Allocates computational tokens to intermediate reasoning states. | Increases output token length and latency (~3x-4x). |
| **4. Verified CoT / Self-Consistency** | Deconstructs the problem into discrete steps, performs sanity checks/verification, then states final answer. | Highest accuracy; catches arithmetic and logical oversights. | Highest latency and token cost. |

---

### 4. PROMPT TEMPLATES

#### 1. Direct (Zero-Shot) Template
```text
Answer the following question directly with only the final answer.
Question: {question}
Answer:
```

#### 2. Few-Shot Template
```text
Follow the format of these examples:
Q: What is 10 plus 4?
A: 14

Q: Is 'radar' a palindrome?
A: yes

Q: If 2 books cost $10, how much does 1 book cost?
A: 5

Q: {question}
A:
```

#### 3. Chain-of-Thought (CoT) Template
```text
Solve the following problem by thinking step by step. State your reasoning clearly, and conclude with 'Final Answer: <answer>'.
Question: {question}
Reasoning:
```

#### 4. Self-Consistency / Verified CoT Template
```text
Deconstruct the problem step by step, verify your calculations against possible edge cases or common fallacies, and provide your validated conclusion as 'Final Answer: <answer>'.
Question: {question}
Step-by-step Analysis & Verification:
```

---

### 5. BENCHMARK DATASET TAXONOMY

The test suite evaluates 10 problems spanning multiple cognitive reasoning domains:
1. **Multi-step Math**: Total cost subtraction ($5 \times \$4 = \$20$; $\$50 - \$20 = \$30$).
2. **Symbolic Reasoning**: Palindrome reversal verification (`racecar`).
3. **Deductive Logic**: Transitive height ordering ($C > A > B \implies \text{Shortest} = B$).
4. **Arithmetic / Percentage**: Multi-operator computation ($20\% \times 150 + 15 = 45$).
5. **Temporal Reasoning**: Clock arithmetic crossing hour boundary ($2:45\text{ PM} + 1\text{h }50\text{m} = 4:35\text{ PM}$).
6. **String / Character Counting**: Letter counting overcoming BPE tokenization (`STRAWBERRY` = 10).
7. **Conditional / Syllogistic Logic**: Non-distributive categorical deduction (Some flowers fade $\nRightarrow$ all roses fade).
8. **Rate / Work Puzzle**: Concurrent worker dimensional analysis ($3\text{ painters}, 3\text{ rooms}, 3\text{ hours} \implies 6\text{ painters}, 6\text{ rooms} = 3\text{ hours}$).
9. **Geometry / Spatial**: Rectangle perimeter ($2 \times (12 + 5) = 34$).
10. **Logic Puzzle**: Resource constraint conflict graph (Wolf-Goat-Cabbage safety).

---

### 6. EXPERIMENTAL RESULTS

#### 6.1 Quantitative Benchmark Summary Table

| Prompting Strategy | Accuracy (%) | Solved / Total | Avg Latency (s) | Avg Prompt Tokens | Avg Completion Tokens | Total Tokens | Token Efficiency (Acc % / 100 Tok) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Direct (Zero-Shot)** | **60.0%** | 6 / 10 | 0.1232s | 28.4 | 3.2 | 316 | **18.99** |
| **Few-Shot** | **80.0%** | 8 / 10 | 0.1843s | 74.8 | 4.8 | 796 | **10.05** |
| **Chain-of-Thought (CoT)** | **100.0%** | 10 / 10 | 0.3860s | 41.2 | 52.4 | 936 | **10.68** |
| **Verified CoT** | **100.0%** | 10 / 10 | 0.5470s | 46.2 | 76.8 | 1,230 | **8.13** |

#### 6.2 Visual Metric Comparison

```
--- ACCURACY COMPARISON (%) ---
Direct (Zero-Shot)               [████████████████████████░░░░░░░░░░░░░░░░]  60.0% (6/10)
Few-Shot                         [████████████████████████████████░░░░░░░░]  80.0% (8/10)
Chain-of-Thought (CoT)           [████████████████████████████████████████] 100.0% (10/10)
Self-Consistency / Verified CoT  [████████████████████████████████████████] 100.0% (10/10)

--- LATENCY COMPARISON (Seconds / Question) ---
Direct (Zero-Shot)               [▓▓▓▓▓▓                             ] 0.1232s
Few-Shot                         [▓▓▓▓▓▓▓▓▓                          ] 0.1843s
Chain-of-Thought (CoT)           [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                ] 0.3860s
Self-Consistency / Verified CoT  [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓        ] 0.5470s

--- TOTAL TOKEN OVERHEAD ---
Direct (Zero-Shot)               [▒▒▒▒▒▒▒                            ]   316 tokens
Few-Shot                         [▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒                ]   796 tokens
Chain-of-Thought (CoT)           [▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒            ]   936 tokens
Self-Consistency / Verified CoT  [▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒     ] 1,230 tokens
```

---

### 7. ERROR ANALYSIS & DISCUSSION

1. **Failure of Intuition in Direct Prompting**:
   - On Question 8 (Rate puzzle: 3 painters paint 3 rooms in 3 hours): Direct prompting predicted **6 hours**, falling into the linear proportionality heuristic trap.
   - On Question 7 (Categorical logic: All roses are flowers, some flowers fade quickly): Direct prompting predicted **yes**, committing the fallacy of illicit conversion.
   - On Question 5 (Time: 2:45 PM + 1h 50m): Direct prompting incorrectly answered **4:15 PM** due to unmanaged modulo-60 rollover.

2. **The Mechanism of Chain-of-Thought**:
   - In CoT, the model generates intermediate tokens that explicitly state sub-goals (e.g., *"1 painter takes 3 hours per room"*).
   - In subsequent token generation steps, the transformer's multi-head self-attention attends to these generated intermediate tokens, effectively treating the output sequence as dynamic scratchpad memory.

3. **Trade-Off Analysis**:
   - CoT provides a massive **+40.0% accuracy gain** over Direct prompting.
   - However, it incurs a **3.1x latency penalty** and a **2.96x token increase**.
   - For high-volume simple classification tasks, Direct or Few-Shot is optimal; for math, logic, and planning, CoT is strictly required.

---

### 8. VIVA VOCE QUESTIONS & ANSWERS

**Q1: What is the fundamental difference between Zero-Shot and Few-Shot prompting?**
> *Answer*: Zero-shot provides only the task prompt and question without exemplars, relying solely on pre-trained knowledge. Few-shot provides $k$ illustrative input-output examples before the target question, leveraging in-context learning to demonstrate output format and task semantics without weight updates.

**Q2: Why does Chain-of-Thought prompting improve reasoning performance on multi-step problems?**
> *Answer*: Transformer attention is bounded per token generation step. By outputting step-by-step intermediate tokens ("scratchpad"), the model breaks a complex compound probability $P(Y \mid X)$ into a sequence of conditioned probabilities $P(step_1 \mid X), P(step_2 \mid X, step_1), \dots$, allowing subsequent attention layers to ground final conclusions in validated intermediate steps.

**Q3: Who proposed Chain-of-Thought prompting and when?**
> *Answer*: Wei et al. (Google Research) in their 2022 paper *"Chain-of-Thought Prompting Elicits Reasoning in Large Language Models"*.

**Q4: What is an "emergent ability" in the context of Chain-of-Thought prompting?**
> *Answer*: An emergent ability is a capability not present in smaller language models (e.g. <10B parameters) that appears abruptly as model scale exceeds a critical threshold (typically >50B to 100B parameters). CoT generally yields flat or negative gains on small models but dramatic gains on large models.

**Q5: What is Self-Consistency in prompting (Wang et al., 2022)?**
> *Answer*: Self-Consistency samples multiple diverse reasoning paths from the LLM at a non-zero temperature and selects the most frequent consensus answer (majority voting), mitigating individual hallucinated steps.

**Q6: What is the primary limitation or drawback of Chain-of-Thought prompting?**
> *Answer*: Increased latency, higher monetary cost due to greater token consumption, and the risk that an early hallucinated step in the reasoning chain cascades into a false conclusion (error propagation).

**Q7: How does tokenization affect character-level or string reasoning tasks?**
> *Answer*: Byte-Pair Encoding (BPE) chunks character sequences into multi-character subword tokens (e.g. "STRAW" + "BERRY"). Because the model does not see individual characters directly, questions like "How many letters in STRAWBERRY?" fail unless prompted with CoT to enumerate letters explicitly.

**Q8: What is the role of temperature in reasoning tasks?**
> *Answer*: For deterministic reasoning and math, temperature should be set to 0 (greedy decoding) to minimize stochastic deviations. For self-consistency or diverse path sampling, a moderate temperature (e.g., 0.5 - 0.7) is used.

**Q9: What metric describes the trade-off between accuracy and cost in this experiment?**
> *Answer*: **Token Efficiency**, defined as Accuracy % achieved per 100 total tokens consumed. Direct prompting had high token efficiency despite lower accuracy, while CoT provided peak accuracy at lower token efficiency.

**Q10: What is the difference between Chain-of-Thought and ReAct prompting?**
> *Answer*: CoT is a static internal reasoning process without external interaction. ReAct (Reasoning + Acting) pairs reasoning traces with external tool executions (e.g., web search, database querying, calculator) in an interactive Thought $\rightarrow$ Action $\rightarrow$ Observation feedback loop.
