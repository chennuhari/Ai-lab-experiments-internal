# Experiment 1: Reasoning Model Benchmark Report

## Executive Summary

This benchmark evaluates LLM reasoning performance across four established prompting paradigms:
1. **Direct (Zero-Shot)**
2. **Few-Shot**
3. **Chain-of-Thought (CoT)**
4. **Self-Consistency / Verified CoT**

### Benchmark Metric Comparison

| Strategy | Accuracy (%) | Avg Latency (s) | Avg Prompt Tok | Avg Compl Tok | Total Tokens | Token Efficiency |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **Direct (Zero-Shot)** | 60.0% | 0.1256s | 42.5 | 1.1 | 436 | 13.76 |
| **Few-Shot** | 80.0% | 0.1838s | 83.0 | 1.1 | 841 | 9.51 |
| **Chain-of-Thought (CoT)** | 100.0% | 0.3858s | 55.2 | 46.7 | 1019 | 9.81 |
| **Self-Consistency / Verified CoT** | 100.0% | 0.5377s | 66.0 | 64.4 | 1304 | 7.67 |

## Key Findings & Critical Analysis

1. **The Reasoning Gap**: Direct prompting failed on multi-step counter-intuitive problems (e.g. rate-work puzzle, syllogism qualification), yielding only **60% accuracy**.
2. **Few-Shot Limitations**: Providing exemplars without step-by-step reasoning improved formatting and surface alignment (**80% accuracy**), but failed to fix deep mathematical logic fallacies.
3. **Chain-of-Thought Superiority**: Chain-of-Thought (CoT) achieved **100% accuracy** by forcing intermediate token generation, unlocking transformer attention across sub-computations.
4. **Cost & Latency Trade-Off**: While CoT and Verified CoT achieved perfect accuracy, they consumed **~3x to 4x more tokens** and took **~3x more latency**. In real-world deployments, prompt strategies must be selected based on the accuracy-criticality of the task.

## Question-by-Question Matrix

| ID | Category | Expected | Direct | Few-Shot | CoT | Verified CoT |
|:---|:---|:---|:---:|:---:|:---:|:---:|
| 1 | Multi-step Math | `30` | ✅ | ✅ | ✅ | ✅ |
| 2 | Symbolic Reasoning | `yes` | ❌ | ✅ | ✅ | ✅ |
| 3 | Deductive Logic | `bob` | ✅ | ✅ | ✅ | ✅ |
| 4 | Arithmetic / Percentage | `45` | ✅ | ✅ | ✅ | ✅ |
| 5 | Temporal Reasoning | `4:35 pm` | ❌ | ❌ | ✅ | ✅ |
| 6 | String / Counting | `10` | ✅ | ✅ | ✅ | ✅ |
| 7 | Conditional Logic | `no` | ❌ | ✅ | ✅ | ✅ |
| 8 | Rate / Work Puzzle | `3` | ❌ | ❌ | ✅ | ✅ |
| 9 | Geometry / Spatial | `34` | ✅ | ✅ | ✅ | ✅ |
| 10 | Logic Puzzle | `yes` | ✅ | ✅ | ✅ | ✅ |
